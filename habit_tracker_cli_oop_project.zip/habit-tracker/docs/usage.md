# Usage Instructions

## Run Python CLI in Codespaces:

```bash
cd habit-tracker/src/python
python app.py
```

## Run Java CLI locally or in Codespaces:

```bash
cd habit-tracker/src/java/cli
javac Main.java ../model/Habit.java ../service/HabitManager.java
java Main
```

## Run Python tests:

```bash
cd habit-tracker
python3 -m unittest discover tests/python
```
