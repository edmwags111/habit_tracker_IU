# System Architecture

Each language (Java and Python) implements the same architecture:
- `Habit`: represents a single habit
- `HabitManager`: manages a collection of habits
- `CLI Interface`: interacts with user input/output

Data is exported to `/data` in CSV format for persistence and analysis.
