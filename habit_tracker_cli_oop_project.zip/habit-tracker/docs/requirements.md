# Functional Requirements

- Habit creation, deletion, check-ins
- Custom frequency settings
- Predefined habits
- Streak tracking and statistics
- Export to CSV
- CLI interaction only

# Non-Functional Requirements

- Full OOP structure in Python and Java
- GitHub Codespaces compatible
- Fast analytics on 1000+ records
- GitHub Actions for testing
