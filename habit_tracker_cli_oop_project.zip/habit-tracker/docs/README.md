# Habit Tracker (CLI – Java & Python)

This is a CLI-based habit tracking app implemented in **both Python and Java** with a strong focus on **Object-Oriented Programming** principles.

The project is fully designed for use inside **GitHub Codespaces** and includes testing, documentation, and CLI interaction only (no GUI).
