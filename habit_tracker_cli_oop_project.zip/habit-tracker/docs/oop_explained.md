# OOP Concepts in Habit Tracker

## 1. Encapsulation
- Classes group data (fields) and behaviors (methods)
- Fields like `checkins` in `Habit` are accessed via methods only

## 2. Abstraction
- `HabitManager` provides a clean API for managing habits without exposing internal structures

## 3. Composition
- `HabitManager` contains multiple `Habit` instances

## 4. Inheritance
- Not applied here explicitly, but extendable for different habit types in future

## 5. Modularity
- Each class in its own file
- Test files separate from logic
