Run Python CLI: `cd src/python && python app.py`
Run tests: `python3 -m unittest discover tests/python`